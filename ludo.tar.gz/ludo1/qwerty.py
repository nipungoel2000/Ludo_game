import pygame.gfxdraw
import pygame , sys
import pygame.draw
pygame.font.init()

size = width, height = 1050, 1020
screen = pygame.display.set_mode(size)


board_places=[(100,400),(150,400),(200,400),(250,400),(300,400),(350,400),(400,350),(400,300),(400,250),(400,200),(400,150),(400,100),(400,50),(450,50),(500,50),(500,100),(500,150),(500,200),(500,250),(500,300),(500,350),(550,400),(600,400,),(650,400),(700,400),(750,400),(800,400),(850,400),(850,450),(850,500),(800,500),(750,500),(700,500),(650,500),(600,500),(550,500),(500,550),(500,600),(500,650),(500,700),(500,750),(500,800),(500,850),(450,850),(400,850),(400,800),(400,750),(400,700),(400,650),(400,600),(400,550),(350,500),(300,500),(250,500),(200,500),(150,500),(100,500),(50,500),(50,450),(50,400)]

red_home = [(i,450) for i in range(100,400,50)]
blue_home = [(450,i) for i in range(100,400,50)]
yellow_home = [(i,450) for i in range(800,500,-50)]
green_home = [(450,i) for i in range(800,500,-50)]

star=pygame.image.load("star1.png")
safePoint=[(150,500),(400,150),(750,400),(500,750),(500,100),(100,400),(800,500),(400,800)]

black=(0,0,0)
brown=(102,51,0)
lightBrown=(153,76,0)
purple=(100,0,100)
red=(153,0,0)
green=(0,153,0)
blue=(0,0,153)
skyBlue=(0,255,255)
yellow=(204,204,0)
dirtyWhite=(200,200,200)
x=(180,180,0)
b_red=(200,0,0)
b_green=(0,200,0)
b_purple=(153,0,153)

boundry_size=30
board_squ_x=50
board_squ_y=50
block_size=50
squ_size=350
board_size = squ_size*2 +block_size*3



board_boundry  = pygame.Rect(board_squ_x - boundry_size , board_squ_y - boundry_size , board_size + boundry_size*2, board_size + boundry_size*2)
size = width, height = 1050, 1020
screen = pygame.display.set_mode(size)
board_play  = pygame.Rect(board_squ_x , board_squ_y , board_size , board_size)
box1 = pygame.Rect(board_squ_x , board_squ_y , squ_size , squ_size)
box2 = pygame.Rect(board_squ_x +block_size*3 +squ_size ,board_squ_y ,squ_size ,squ_size)
box3 = pygame.Rect(board_squ_x , board_squ_y +block_size*3 +squ_size , squ_size , squ_size)
box4 = pygame.Rect(board_squ_x +block_size*3 +squ_size , board_squ_y +block_size*3 +squ_size , squ_size , squ_size)

def button(text,x,y,w,h,c1,c2,objective=None):
	m = pygame.mouse.get_pos()
	c = pygame.mouse.get_pressed()
	if x < m[0] < x+w and y < m[1] < y+h:
		pygame.draw.rect(screen,c2,(x,y,w,h))
		if c[0]==1 and objective != None:

			objective()
			return False


	else:
		pygame.draw.rect(screen,c1,(x,y,w,h))
	font=pygame.font.Font('freesansbold.ttf',25)
	m = font.render(text, True, black)
	screen.blit(m,(x+(w/5),y+(h/3)))
	return True



def t_obj(text,font):
    textSurface = font.render(text,True,black)
    return textSurface,textSurface.get_rect()

def message(text):
    msg = pygame.font.Font('freesansbold.ttf',115)
    TextSurface, TextRect = t_obj(text, msg)
    TextRect.center = ((width/2),(height/8))
    screen.blit(TextSurface,TextRect)

def draw_grid(start_x,start_y,board_squ_x):
	i = board_squ_x
	while(i<board_squ_x + board_size):
		pygame.gfxdraw.hline(screen,start_x,start_x + board_size,i,black)
		pygame.gfxdraw.vline(screen,i,start_y,start_y + board_size,black)
		i+=board_squ_x

def draw_circles(X,Y,r):
	x=X+100
	y=Y+100
	pygame.gfxdraw.filled_circle(screen,x,y,r+2,black)
	pygame.gfxdraw.filled_circle(screen,x+150,y,r+2,black)
	pygame.gfxdraw.filled_circle(screen,x,y+150,r+2,black)
	pygame.gfxdraw.filled_circle(screen,x+150,y+150,r+2,black)

	pygame.gfxdraw.filled_circle(screen,x,y,r,dirtyWhite)
	pygame.gfxdraw.filled_circle(screen,x+150,y,r,dirtyWhite)
	pygame.gfxdraw.filled_circle(screen,x,y+150,r,dirtyWhite)
	pygame.gfxdraw.filled_circle(screen,x+150,y+150,r,dirtyWhite)

def addstar():
	for i in range(len(safePoint)):
		screen.blit(star,safePoint[i])

def game_loop():

	while 1:
		for event in pygame.event.get():
			if event.type==pygame.QUIT:
				pygame.quit()
				quit()
			board()
			pygame.display.flip()



def board():
	screen.fill(black)
	pygame.gfxdraw.box(screen,board_boundry,brown)
	pygame.gfxdraw.box(screen,board_play,dirtyWhite)
	pygame.draw.polygon(screen,red,((100,400),(150,400),(150,450),(400,450),(400,500),(100,500)),0)
	pygame.draw.polygon(screen,blue,((550,100),(450,100),(450,400),(500,400),(500,150),(550,150)),0)
	pygame.draw.polygon(screen,green,((450,800),(450,550),(500,550),(500,850),(400,850),(400,800)),0)
	pygame.draw.polygon(screen,yellow,((550,450),(850,450),(850,550),(800,550),(800,500),(550,500)),0)
	draw_grid(board_squ_x,board_squ_y,board_squ_x)
	pygame.gfxdraw.box(screen,box1,red)
	pygame.gfxdraw.box(screen,box2,blue)
	pygame.gfxdraw.box(screen,box3,green)
	pygame.gfxdraw.box(screen,box4,yellow)
	pygame.draw.polygon(screen,red,((400,400),(475,475),(400,550)),0)
	pygame.draw.polygon(screen,blue,((400,400),(475,475),(550,400)),0)
	pygame.draw.polygon(screen,green,((400,550),(475,475),(550,550)),0)
	pygame.draw.polygon(screen,yellow,((550,400),(475,475),(550,550)),0)
	pygame.draw.rect(screen, black, [board_squ_x , board_squ_y , squ_size , squ_size], 2)
	pygame.draw.rect(screen, black, [board_squ_x +block_size*3 +squ_size ,board_squ_y ,squ_size ,squ_size], 2)
	pygame.draw.rect(screen, black, [board_squ_x , board_squ_y +block_size*3 +squ_size , squ_size , squ_size], 2)
	pygame.draw.rect(screen, black, [board_squ_x +block_size*3 +squ_size , board_squ_y +block_size*3 +squ_size , squ_size , squ_size], 2)
	pygame.draw.rect(screen, black, [400,400,150,150], 2)
	draw_circles(board_squ_x , board_squ_y,30)
	draw_circles(board_squ_x +block_size*3 +squ_size ,board_squ_y,30 )
	draw_circles(board_squ_x , board_squ_y +block_size*3 +squ_size,30)
	draw_circles(board_squ_x +block_size*3 +squ_size , board_squ_y +block_size*3 +squ_size,30)
	addstar()

def quitgame():
	pygame.quit()
#(TO BE ADDED OR NOT)def instructions():
def initial():
	page = True
	while page:
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				pygame.quit()

		screen.fill(x)
		message("LUDO")
		X=button("Play",400,250,200,60,green,b_green,game_loop)
		Y=button("Instructions",400,350,200,60,purple,b_purple)
		Z=button("Quit",400,450,200,60,red,b_red,quitgame)
		pygame.display.update()
		if (X and Y and Z)==False:
			page=False






board_places=[(100,400),(150,400),(200,400),(250,400),(300,400),(350,400),(400,350),(400,300),(400,250),(400,200),(400,150),(400,100),(400,50),(450,50),(500,50),(500,100),(500,150),(500,200),(500,250),(500,300),(500,350),(550,400),(600,400,),(650,400),(700,400),(750,400),(800,400),(850,400),(850,450),(850,500),(800,500),(750,500),(700,500),(650,500),(600,500),(550,500),(500,550),(500,600),(500,650),(500,700),(500,750),(500,800),(500,850),(450,850),(400,850),(400,800),(400,750),(400,700),(400,650),(400,600),(400,550),(350,500),(300,500),(250,500),(200,500),(150,500),(100,500),(50,500),(50,450),(50,400)]

red_home = [(i,450) for i in range(100,400,50)]
blue_home = [(450,i) for i in range(100,400,50)]
yellow_home = [(i,450) for i in range(800,500,-50)]
green_home = [(450,i) for i in range(800,500,-50)]
safePoint=[(150,500),(400,150),(750,400),(500,750),(500,100),(100,400),(800,500),(400,800)]
default_red = [(150-25,150-25),(300-25,150-25),(300-25,300-25),(150-25,300-25)]
default_blue =[(650-25,150-25),(650-25,300-25),(800-25,150-25),(800-25,300-25)]
default_green =[(150-25,650-25),(300-25,650-25),(150-25,800-25),(300-25,800-25)]
default_yellow =[(650-25,650-25),(800-25,650-25),(800-25,800-25),(650-25,800-25)]

active_tokens=[]
inactive_red=[]
inactive_blue=[]
inactive_green=[]
inactive_yellow=[]
playtokens=[]
players=[]

neon=(170,242,0)
black=(0,0,0)
brown=(102,51,0)
lightBrown=(153,76,0)
purple=(100,0,100)
red=(153,0,0)
green=(0,153,0)
blue=(0,0,153)
skyBlue=(0,255,255)
yellow=(204,204,0)
dirtyWhite=(200,200,200)
x=(180,180,0)
b_red=(200,0,0)
b_green=(0,200,0)
b_purple=(153,0,153)



def set_default(color):
	if color==red:
		l=inactive_red
		q=default_red
	elif color==blue:
		l=inactive_blue
		q=default_blue
	elif color==green:
		l=inactive_green
		q=default_green
	elif color==yellow:
		l=inactive_yellow
		q=default_yellow

	for i in range(len(l)):
		l[i].position=q[i]


def make_the_board():
	board={}
	for i in board_places:
		board[i]=[]
	for i in blue_home:
		board[i]=[]
	for i in red_home:
		board[i]=[]
	for i in green_home:
		board[i]=[]
	for i in yellow_home:
		board[i]=[]

	for i in default_red:
		board[i]=[]
	for i in default_blue:
		board[i]=[]
	for i in default_yellow:
		board[i]=[]
	for i in default_green:
		board[i]=[]


	return board	

theBoard=make_the_board()


class token:
	def __init__(self, color):
		self.color=color
		if self.color==red:
			self.pos_pointer=0
			self.position=board_places[self.pos_pointer]

		elif self.color==blue:
			self.pos_pointer=15
			self.position=board_places[self.pos_pointer]

		elif self.color==green:
			self.pos_pointer=45
			self.position=board_places[self.pos_pointer]

		elif self.color==yellow:
			self.pos_pointer=30
			self.position=board_places[self.pos_pointer]
		self.deactivate()



	def get_roll(self,dice):
		for i in range(len(theBoard[self.position])):   # we need to pop the token from the old position before appending it to the new location  theBoard[pos] 
			if theBoard[self.position][i]==self:
				theBoard[self.position].pop(i)
		if self not in active_tokens:
			if self.color==red:
				self.pos_pointer=0+dice-6
	
			elif self.color==blue:
				self.pos_pointer=15+dice-6
	
			elif self.color==green:
				self.pos_pointer=45+dice-6
	
			elif self.color==yellow:
				self.pos_pointer=30+dice-6

			self.activate()
		else:
			self.pos_pointer+=dice
			
		self.update_pos()
		self.place_token()



	def update_pos(self):
		if self.color==red:
			if self.pos_pointer>=len(board_places):
				self.position=red_home[self.pos_pointer-len(board_places)]
			else:
				self.position=board_places[self.pos_pointer]

		elif self.color==blue:
			if self.pos_pointer>=len(board_places):
				if self.pos_pointer<=len(board_places)+15:
					self.position=board_places[self.pos_pointer-len(board_places)]
				else:					
					self.position=blue_home[self.pos_pointer-len(board_places)-15]
			else:
				self.position=board_places[self.pos_pointer]

		elif self.color==green:
			if self.pos_pointer>=len(board_places):
				if self.pos_pointer<=len(board_places)+45:
					self.position=board_places[self.pos_pointer-len(board_places)]
				else:					
					self.position=green_home[self.pos_pointer-len(board_places)-45]
			else:
				self.position=board_places[self.pos_pointer]

		elif self.color==yellow:
			if self.pos_pointer>=len(board_places):
				if self.pos_pointer<=len(board_places)+30:
					self.position=board_places[self.pos_pointer-len(board_places)]
				else:					
					self.position=yellow_home[self.pos_pointer-len(board_places)-30]
			else:
				self.position=board_places[self.pos_pointer]

	def display_token(self):
		x=self.position[0]
		y=self.position[1]
		pygame.gfxdraw.filled_circle(screen,x+25,y+25,25,self.color)

	def click_token(self ,die):
		mouse = pygame.mouse.get_pos()
		click = pygame.mouse.get_pressed()
		x = self.position[0]
		y = self.position[1]
		w = 50
		h =50
		pygame.gfxdraw.filled_circle(screen,x+25,y+25,25,neon)
		pygame.gfxdraw.filled_circle(screen,x+25,y+25,23,self.color)
		if x+w>mouse[0]>x and y+h>mouse[1]>y:
			if(click[0]==1):
				self.get_roll(die)
				return False
			else:
				return True
		else:
			return True



	def place_token(self):
		X=self.what_is_there()
		if X[0]:
			if [1]:
				theBoard[self.position].append(self)
			else:
				self.reset_pos()            #some reset function for theBoard[pos] that-is the whole list (not theBoard dictionary) 
				theBoard[self.position]=[self]
		else:
			theBoard[self.position].append(self)


	def what_is_there(self):
		if theBoard[self.position]==[] or self.position in safePoint:
			return (False)
		else:
			if theBoard[self.position][0].color==self.color:
				return (True,True)
			else:
				return (True,False)



	def deactivate(self):
		for i in range(len(active_tokens)):
			if active_tokens[i]==self:
				active_tokens.pop(i)
		if self.color==red:
			inactive_red.append(self)
		elif self.color==blue:
			inactive_blue.append(self)
		elif self.color==green:
			inactive_green.append(self)
		elif self.color==yellow:
			inactive_yellow.append(self)


	def activate(self):
		active_tokens.append(self)
		if self.color==red:
			for i in inactive_red:
				if i==self:
					inactive_red.remove(i)
		elif self.color==blue:
			for i in inactive_blue:
				if i==self:
					inactive_blue.remove(i)
		elif self.color==green:
			for i in inactive_green:
				if i==self:
					inactive_green.remove(i)
		elif self.color==yellow:
			for i in inactive_yellow:
				if i==self:
					inactive_yellow.remove(i)


	def reset_pos(self):
		for i in Theboard[self.position]:
			i.deactivate()
			color=i.color
		set_default(color)



'''
we can make a global dictionary of positions as key values and empty list as the value 
and each of the tokens has its own position_ variable as well
and we check in the dictionary if there is any thing there 

if it is of the same color then  append 
or if the position is a safe house then append

else the old will reset and the new will be added 
 
 
'''


import random



namelist=["utkarsh","neetha","nipun","NONE"]

if namelist[0]!="NONE":
	r1=token(red)
	r2 = token(red)
	r3 = token(red)
	r4 = token(red)
	playtokens.append(r1)
	playtokens.append(r2)
	playtokens.append(r3)
	playtokens.append(r4)
	players.append((red,namelist[0]))

if namelist[1]!="NONE":
	g1 = token(green)
	g2 = token(green)
	g3 = token(green)
	g4 = token(green)
	playtokens.append(g1)
	playtokens.append(g2)
	playtokens.append(g3)
	playtokens.append(g4)
	players.append((green,namelist[1]))

if namelist[2]!="NONE":
	b1 = token(blue)
	b2 = token(blue)
	b3 = token(blue)
	b4 = token(blue)
	playtokens.append(b1)
	playtokens.append(b2)
	playtokens.append(b3)
	playtokens.append(b4)
	players.append((blue,namelist[2]))

if namelist[3]!="NONE":
	y1 = token(yellow)
	y2 = token(yellow)
	y3 = token(yellow)
	y4 = token(yellow)
	playtokens.append(y1)
	playtokens.append(y2)
	playtokens.append(y3)
	playtokens.append(y4)
	players.append((yellow,namelist[3]))



def die_button():
	x = random.randint(1,6)
	if(x==6):
		x = x+random.randint(1,6)
	if(x==12):
		x+=random.randint(1,6)
	if(x==18):
		return 0
	return x
		

def gameloop():
	for i in players:
		set_default(i[0])
	while 1:
		for j in range(len(players)):
			board()		
			for i in playtokens:
				i.display_token()
	
			die = die_button()
			flag = True
			if die ==0:
				flag =False
			print (die)
			while flag:
				for event in pygame.event.get():
					if event.type==pygame.QUIT:
						pygame.quit()
						quit()

				if(die>6):
					for i in playtokens:
						if(i.color==players[j][0]):
							x=i.click_token(die)
							flag=flag and x
				else:
					for i in playtokens:
						if(i.color==players[j][0]):
							if i.color==red:
								if len(inactive_red)==4:
									flag=False
							elif i.color==blue:
								if len(inactive_blue)==4:
									flag=False
							elif i.color==green:
								if len(inactive_green)==4:
									flag=False
							elif i.color==yellow:
								if len(inactive_yellow)==4:
									flag=False


							if i in active_tokens:
								x=i.click_token(die)
								flag=flag and x
				pygame.display.update()
				pygame.display.flip()


gameloop()



			





		
