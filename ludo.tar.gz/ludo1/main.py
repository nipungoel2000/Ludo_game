from token_class import *
from board import *
import random



namelist=["utkarsh","neetha","nipun","NONE"]

if namelist[0]!="NONE":
	r1=token(red)
	r2 = token(red)
	r3 = token(red)
	r4 = token(red)
	playtokens.append(r1)
	playtokens.append(r2)
	playtokens.append(r3)
	playtokens.append(r4)
	players.append((red,namelist[0]))

elif namelist[1]!="NONE":
	g1 = token(green)
	g2 = token(green)
	g3 = token(green)
	g4 = token(green)
	playtokens.append(g1)
	playtokens.append(g2)
	playtokens.append(g3)
	playtokens.append(g4)
	players.append((green,namelist[1]))

elif namelist[2]!="NONE":
	b1 = token(blue)
	b2 = token(blue)
	b3 = token(blue)
	b4 = token(blue)
	playtokens.append(b1)
	playtokens.append(b2)
	playtokens.append(b3)
	playtokens.append(b4)
	players.append((blue,namelist[2]))

elif namelist[3]!="NONE":
	y1 = token(yellow)
	y2 = token(yellow)
	y3 = token(yellow)
	y4 = token(yellow)
	playtokens.append(y1)
	playtokens.append(y2)
	playtokens.append(y3)
	playtokens.append(y4)
	players.append((yellow,namelist[3]))



def die_button():
	x = random.randint(1,6)
	if(x==6):
		x = x+random.randint(1,6)
	if(x==12):
		x+=random.randint(1,6)
	if(x==18):
		return 0
	return x
		

def gameloop():
	for i in players:
		set_default(i[0])
	while 1:
		for j in range(len(players)):
			board()		
			for i in playtokens:
				i.display_token()
	
			die = die_button()
			flag = True
			if die ==0:
				flag =False
			while flag:
				if(die>6):
					for i in playtokens:
						if(i.color==players[j][0]):
							x=i.click_token(die)
							flag=flag and x
				else:
					for i in playtokens:
						if(i.color==players[j][0]):
							if i in active_token:
								x=i.click_token(die)
								flag=flag and x
				




			





		
