from board import *

board_places=[(100,400),(150,400),(200,400),(250,400),(300,400),(350,400),(400,350),(400,300),(400,250),(400,200),(400,150),(400,100),(400,50),(450,50),(500,50),(500,100),(500,150),(500,200),(500,250),(500,300),(500,350),(550,400),(600,400,),(650,400),(700,400),(750,400),(800,400),(850,400),(850,450),(850,500),(800,500),(750,500),(700,500),(650,500),(600,500),(550,500),(500,550),(500,600),(500,650),(500,700),(500,750),(500,800),(500,850),(450,850),(400,850),(400,800),(400,750),(400,700),(400,650),(400,600),(400,550),(350,500),(300,500),(250,500),(200,500),(150,500),(100,500),(50,500),(50,450),(50,400)]

red_home = [(i,450) for i in range(100,400,50)]
blue_home = [(450,i) for i in range(100,400,50)]
yellow_home = [(i,450) for i in range(800,500,-50)]
green_home = [(450,i) for i in range(800,500,-50)]
safePoint=[(150,500),(400,150),(750,400),(500,750),(500,100),(100,400),(800,500),(400,800)]
default_red = [(150,150),(300,150),(300,300),(150,300)]
default_blue =[(650,150),(650,300),(800,150),(800,300)]
default_green =[(150,650),(300,650),(150,800),(300,800)]
default_yellow =[(650,650),(800,650),(800,800),(650,800)]

active_tokens=[]
inactive_red=[]
inactive_blue=[]
inactive_green=[]
inactive_yellow=[]
playtokens=[]
players=[]

neon=(170,242,0)
black=(0,0,0)
brown=(102,51,0)
lightBrown=(153,76,0)
purple=(100,0,100)
red=(153,0,0)
green=(0,153,0)
blue=(0,0,153)
skyBlue=(0,255,255)
yellow=(204,204,0)
dirtyWhite=(200,200,200)
x=(180,180,0)
b_red=(200,0,0)
b_green=(0,200,0)
b_purple=(153,0,153)



def set_default(color):
	if color==red:
		l=inactive_red
		q=default_red
	elif color==blue:
		l=inactive_blue
		q=default_blue
	elif color==green:
		l=inactive_green
		q=default_green
	elif color==yellow:
		l=inactive_yellow
		q=default_yellow

	for i in range(len(l)):
		l[i].position=q[i]


def make_the_board():
	board={}
	for i in board_places:
		board[i]=[]
	for i in blue_home:
		board[i]=[]
	for i in red_home:
		board[i]=[]
	for i in green_home:
		board[i]=[]
	for i in yellow_home:
		board[i]=[]

	return board	

theBoard=make_the_board()


class token:
	def __init__(self, color):
		self.color=color
		if self.color==red:
			self.pos_pointer=0
			self.position=board_places[self.pos_pointer]

		elif self.color==blue:
			self.pos_pointer=15
			self.position=board_places[self.pos_pointer]

		elif self.color==green:
			self.pos_pointer=45
			self.position=board_places[self.pos_pointer]

		elif self.color==yellow:
			self.pos_pointer=30
			self.position=board_places[self.pos_pointer]
		self.deactivate()



	def get_roll(self,dice):
		for i in range(len(theBoard[self.position])):   # we need to pop the token from the old position before appending it to the new location  theBoard[pos] 
			if theBoard[self.position][i]==self:
				theBoard[self.position].pop(i)
		if i not in active_tokens:
			if self.color==red:
				self.pos_pointer=0+dice-6
	
			elif self.color==blue:
				self.pos_pointer=15+dice-6
	
			elif self.color==green:
				self.pos_pointer=45+dice-6
	
			elif self.color==yellow:
				self.pos_pointer=30+dice-6

			activate(self)
		else:
			self.pos_pointer+=dice
			
		self.update_pos()
		self.place_token()



	def update_pos(self):
		if self.color==red:
			if self.pos_pointer>=len(board_places):
				self.position=red_home[self.pos_pointer-len(board_places)]
			else:
				self.position=board_places[self.pos_pointer]

		elif self.color==blue:
			if self.pos_pointer>=len(board_places):
				if self.pos_pointer<=len(board_places)+15:
					self.position=board_places[self.pos_pointer-len(board_places)]
				else:					
					self.position=blue_home[self.pos_pointer-len(board_places)-15]
			else:
				self.position=board_places[self.pos_pointer]

		elif self.color==green:
			if self.pos_pointer>=len(board_places):
				if self.pos_pointer<=len(board_places)+45:
					self.position=board_places[self.pos_pointer-len(board_places)]
				else:					
					self.position=green_home[self.pos_pointer-len(board_places)-45]
			else:
				self.position=board_places[self.pos_pointer]

		elif self.color==yellow:
			if self.pos_pointer>=len(board_places):
				if self.pos_pointer<=len(board_places)+30:
					self.position=board_places[self.pos_pointer-len(board_places)]
				else:					
					self.position=yellow_home[self.pos_pointer-len(board_places)-30]
			else:
				self.position=board_places[self.pos_pointer]

	def display_token(self):
		x=self.position[0]
		y=self.position[1]
		pygame.gfxdraw.filled_circle(screen,x+25,y+25,25,self.color)

	def click_token(self ,die):
		mouse = pygame.mouse.get_pos()
		click = pygame.mouse.get_pressed()
		x = self.position[0]
		y = self.position[1]
		w = 50
		h =50
		pygame.gfxdraw.filled_circle(screen,x+25,y+25,25,neon)
		pygame.gfxdraw.filled_circle(screen,x+25,y+25,23,self.color)
		if x+w>mouse[0]>x and y+h>mouse[1]>y:
			if(click[0]==1):
				self.get_roll(die)
				return False
			else:
				return True



	def place_token(self):
		X=self.what_is_there()
		if X[0]:
			if [1]:
				theBoard[self.position].append(self)
			else:
				self.reset_pos()            #some reset function for theBoard[pos] that-is the whole list (not theBoard dictionary) 
				theBoard[self.position]=[self]
		else:
			theBoard[self.position].append(self)


	def what_is_there(self):
		if theBoard[self.position]==[] or self.position in safePoint:
			return (False)
		else:
			if theBoard[self.position][0].color==self.color:
				return (True,True)
			else:
				return (True,False)



	def deactivate(self):
		for i in range(len(active_tokens)):
			if active_tokens[i]==self:
				active_tokens.pop(i)
		if self.color==red:
			inactive_red.append(self)
		elif self.color==blue:
			inactive_blue.append(self)
		elif self.color==green:
			inactive_green.append(self)
		elif self.color==yellow:
			inactive_yellow.append(self)


	def activate(self):
		active_tokens.append(self)
		if self.color==red:
			for i in range(len(inactive_red)):
				if inactive_red[i]==self:
					inactive_red.pop(i)
		elif self.color==blue:
			for i in range(len(inactive_blue)):
				if inactive_blue[i]==self:
					inactive_blue.pop(i)
		elif self.color==green:
			for i in range(len(inactive_green)):
				if inactive_green[i]==self:
					inactive_green.pop(i)
		elif self.color==yellow:
			for i in range(len(inactive_yellow)):
				if inactive_yellow[i]==self:
					inactive_yellow.pop(i)



	def reset_pos(self):
		for i in Theboard[self.position]:
			i.deactivate()
			color=i.color
		set_default(color)



'''
we can make a global dictionary of positions as key values and empty list as the value 
and each of the tokens has its own position_ variable as well
and we check in the dictionary if there is any thing there 

if it is of the same color then  append 
or if the position is a safe house then append

else the old will reset and the new will be added 
 
 
'''



