import pygame.gfxdraw
import pygame , sys
import pygame.draw
pygame.font.init()

size = width, height = 1050, 1020
screen = pygame.display.set_mode(size)


board_places=[(100,400),(150,400),(200,400),(250,400),(300,400),(350,400),(400,350),(400,300),(400,250),(400,200),(400,150),(400,100),(400,50),(450,50),(500,50),(500,100),(500,150),(500,200),(500,250),(500,300),(500,350),(550,400),(600,400,),(650,400),(700,400),(750,400),(800,400),(850,400),(850,450),(850,500),(800,500),(750,500),(700,500),(650,500),(600,500),(550,500),(500,550),(500,600),(500,650),(500,700),(500,750),(500,800),(500,850),(450,850),(400,850),(400,800),(400,750),(400,700),(400,650),(400,600),(400,550),(350,500),(300,500),(250,500),(200,500),(150,500),(100,500),(50,500),(50,450),(50,400)]

red_home = [(i,450) for i in range(100,400,50)]
blue_home = [(450,i) for i in range(100,400,50)]
yellow_home = [(i,450) for i in range(800,500,-50)]
green_home = [(450,i) for i in range(800,500,-50)]

star=pygame.image.load("star1.png")
safePoint=[(150,500),(400,150),(750,400),(500,750),(500,100),(100,400),(800,500),(400,800)]

black=(0,0,0)
brown=(102,51,0)
lightBrown=(153,76,0)
purple=(100,0,100)
red=(153,0,0)
green=(0,153,0)
blue=(0,0,153)
skyBlue=(0,255,255)
yellow=(204,204,0)
dirtyWhite=(200,200,200)
x=(180,180,0)
b_red=(200,0,0)
b_green=(0,200,0)
b_purple=(153,0,153)

boundry_size=30
board_squ_x=50
board_squ_y=50
block_size=50
squ_size=350
board_size = squ_size*2 +block_size*3



board_boundry  = pygame.Rect(board_squ_x - boundry_size , board_squ_y - boundry_size , board_size + boundry_size*2, board_size + boundry_size*2)
size = width, height = 1050, 1020
screen = pygame.display.set_mode(size)
board_play  = pygame.Rect(board_squ_x , board_squ_y , board_size , board_size)
r1 = pygame.Rect(board_squ_x , board_squ_y , squ_size , squ_size)
r2 = pygame.Rect(board_squ_x +block_size*3 +squ_size ,board_squ_y ,squ_size ,squ_size)
r3 = pygame.Rect(board_squ_x , board_squ_y +block_size*3 +squ_size , squ_size , squ_size)
r4 = pygame.Rect(board_squ_x +block_size*3 +squ_size , board_squ_y +block_size*3 +squ_size , squ_size , squ_size)

def button(text,x,y,w,h,c1,c2,objective=None):
	m = pygame.mouse.get_pos()
	c = pygame.mouse.get_pressed()
	if x < m[0] < x+w and y < m[1] < y+h:
		pygame.draw.rect(screen,c2,(x,y,w,h))
		if c[0]==1 and objective != None:

			objective()
			return False


	else:
		pygame.draw.rect(screen,c1,(x,y,w,h))
	font=pygame.font.Font('freesansbold.ttf',25)
	m = font.render(text, True, black)
	screen.blit(m,(x+(w/5),y+(h/3)))
	return True



def t_obj(text,font):
    textSurface = font.render(text,True,black)
    return textSurface,textSurface.get_rect()

def message(text):
    msg = pygame.font.Font('freesansbold.ttf',115)
    TextSurface, TextRect = t_obj(text, msg)
    TextRect.center = ((width/2),(height/8))
    screen.blit(TextSurface,TextRect)

def draw_grid(start_x,start_y,board_squ_x):
	i = board_squ_x
	while(i<board_squ_x + board_size):
		pygame.gfxdraw.hline(screen,start_x,start_x + board_size,i,black)
		pygame.gfxdraw.vline(screen,i,start_y,start_y + board_size,black)
		i+=board_squ_x

def draw_circles(X,Y,r):
	x=X+100
	y=Y+100
	pygame.gfxdraw.filled_circle(screen,x,y,r+2,black)
	pygame.gfxdraw.filled_circle(screen,x+150,y,r+2,black)
	pygame.gfxdraw.filled_circle(screen,x,y+150,r+2,black)
	pygame.gfxdraw.filled_circle(screen,x+150,y+150,r+2,black)

	pygame.gfxdraw.filled_circle(screen,x,y,r,dirtyWhite)
	pygame.gfxdraw.filled_circle(screen,x+150,y,r,dirtyWhite)
	pygame.gfxdraw.filled_circle(screen,x,y+150,r,dirtyWhite)
	pygame.gfxdraw.filled_circle(screen,x+150,y+150,r,dirtyWhite)

def addstar():
	for i in range(len(safePoint)):
		screen.blit(star,safePoint[i])

def game_loop():

	while 1:
		for event in pygame.event.get():
			if event.type==pygame.QUIT:
				pygame.quit()
				quit()
			board()
			pygame.display.flip()



def board():
	screen.fill(black)
	pygame.gfxdraw.box(screen,board_boundry,brown)
	pygame.gfxdraw.box(screen,board_play,dirtyWhite)
	pygame.draw.polygon(screen,red,((100,400),(150,400),(150,450),(400,450),(400,500),(100,500)),0)
	pygame.draw.polygon(screen,blue,((550,100),(450,100),(450,400),(500,400),(500,150),(550,150)),0)
	pygame.draw.polygon(screen,green,((450,800),(450,550),(500,550),(500,850),(400,850),(400,800)),0)
	pygame.draw.polygon(screen,yellow,((550,450),(850,450),(850,550),(800,550),(800,500),(550,500)),0)
	draw_grid(board_squ_x,board_squ_y,board_squ_x)
	pygame.gfxdraw.box(screen,r1,red)
	pygame.gfxdraw.box(screen,r2,blue)
	pygame.gfxdraw.box(screen,r3,green)
	pygame.gfxdraw.box(screen,r4,yellow)
	pygame.draw.polygon(screen,red,((400,400),(475,475),(400,550)),0)
	pygame.draw.polygon(screen,blue,((400,400),(475,475),(550,400)),0)
	pygame.draw.polygon(screen,green,((400,550),(475,475),(550,550)),0)
	pygame.draw.polygon(screen,yellow,((550,400),(475,475),(550,550)),0)
	pygame.draw.rect(screen, black, [board_squ_x , board_squ_y , squ_size , squ_size], 2)
	pygame.draw.rect(screen, black, [board_squ_x +block_size*3 +squ_size ,board_squ_y ,squ_size ,squ_size], 2)
	pygame.draw.rect(screen, black, [board_squ_x , board_squ_y +block_size*3 +squ_size , squ_size , squ_size], 2)
	pygame.draw.rect(screen, black, [board_squ_x +block_size*3 +squ_size , board_squ_y +block_size*3 +squ_size , squ_size , squ_size], 2)
	pygame.draw.rect(screen, black, [400,400,150,150], 2)
	draw_circles(board_squ_x , board_squ_y,30)
	draw_circles(board_squ_x +block_size*3 +squ_size ,board_squ_y,30 )
	draw_circles(board_squ_x , board_squ_y +block_size*3 +squ_size,30)
	draw_circles(board_squ_x +block_size*3 +squ_size , board_squ_y +block_size*3 +squ_size,30)
	addstar()

def quitgame():
	pygame.quit()
#(TO BE ADDED OR NOT)def instructions():
def initial():
	page = True
	while page:
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				pygame.quit()

		screen.fill(x)
		message("LUDO")
		X=button("Play",400,250,200,60,green,b_green,game_loop)
		Y=button("Instructions",400,350,200,60,purple,b_purple)
		Z=button("Quit",400,450,200,60,red,b_red,quitgame)
		pygame.display.update()
		if (X and Y and Z)==False:
			page=False

if __name__=="__main__":

		initial()
		game_loop()
